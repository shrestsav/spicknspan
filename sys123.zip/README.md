# Spick N Span
Laravel Project to track the attendance records of all the Employees

Clone the Repository anywhere
Open terminal at cloned repo and "Composer Update" composer needs to be installed
Create env and database, Run command "PHP Artisan Migrate"
