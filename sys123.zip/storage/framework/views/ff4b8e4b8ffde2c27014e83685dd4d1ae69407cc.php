<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      <?php endif; ?>
      <?php if(\Session::has('message')): ?>
        <div class="alert alert-success custom_success_msg">
            <?php echo e(\Session::get('message')); ?>

        </div>
      <?php endif; ?>
        <!--<div class="col-xs-12">-->
            <div class="box box-info">
                <div class="box-header">
                    <h3 class="box-title">Roster Variation List</h3>
                    <p class="pull-right">
                        <label for="">Month-Year</label>
                        <input name="full_date" type="text" id="full_date" class="txtTime" style="width:85px;" autocomplete="off">
                        <a id="contentSection_btnRefresh" class="btn btn-warning" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$contentSection$btnRefresh", "", true, "validation", "", false, true))' style="margin-top: -7px !important;"><i class="fa fa-refresh"></i></a>
                    </p>
                </div>

                <table id="tblRosterVariation" class="table table-hover dataTable no-footer order-list table-striped" role="grid" aria-describedby="tblRoster_info">
              <thead>
                  <tr role="row">
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Date</th>
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Client Name</th>
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Employee Name</th>
                      <!-- <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Created By</th> -->
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Total Hours</th>
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Rostered Hours</th>
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Variation Hours</th>
                      <th style="width: 100px;" class="sorting_disabled" rowspan="1" colspan="1">Action</th>
                    </tr>
              </thead>

              <tbody class="roster-list">
                <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="text-align: center;" role="row" class="odd">
                    
                        <td>
                            <?php $date = $variation->created_at;
                            $date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('Y-m-d');?>
                            <div class="date"><?php echo $date;?></div>
                        </td>
                        <td>
                            <div class="client_name">
                                <?php $__currentLoopData = $user_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user_list->id == $variation->client_id): ?>
                                        <?php echo e($user_list->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td>
                            <div class="employee_name">
                                <?php $__currentLoopData = $user_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user_list->id == $variation->employee_id): ?>
                                        <?php echo e($user_list->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <!-- <td>
                            <div class="created_by">Admin</div>
                        </td> -->
                        <td>
                            <div class="total_hours">
                              <?php $roster_val = DB::table('rosters')
                                            ->where('employee_id','=',$variation->employee_id)
                                            ->where('client_id','=',$variation->client_id)
                                            ->where('full_date','=',$date)
                                            ->get();
                                    $roster_val = json_decode($roster_val, true);

                                    if(!empty($roster_val)){
                                      $check_in  = $roster_val[0]['start_time'];
                                      $check_out = $roster_val[0]['end_time'];

                                      $tot_hours = round(abs(strtotime($check_in) - strtotime($check_out)) / 3600,2). " Hours";
                                      echo $tot_hours;
                                    }
                              ?>
                            </div>
                        </td>
                        <td>
                            <div class="rostered_hours">
                              <?php $check_in  = $variation->check_in;
                                    $check_out = $variation->check_out;
                                    $rost_hours = round(abs(strtotime($check_in) - strtotime($check_out)) / 3600,2). " Hours";
                                    echo $rost_hours;
                              ?>
                            </div>
                        </td>
                        <td>
                            <div class="diff_hours">
                                <?php echo $rost_hours;?>
                            </div>
                        </td>
                        <td>
                          <?php if($variation->status == '2'){ ?>
                            <div class="action">
                                <form action="<?php echo e(url('/roster-variation/accept/').'/'.$variation->id); ?>" method="POST">
                                  <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="_method" value="POST">
                                  <button  class="btn btn-info">Approve</button>
                                </form>
                                <form action="<?php echo e(url('/roster-variation/decline/').'/'.$variation->id); ?>" method="POST">
                                  <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="_method" value="POST">
                                  <button class="btn btn-warning">Decline</button>
                                </form>
                            </div>
                          <?php } else { ?>
                            <div class="declined_message">Variation Declined</div>
                          <?php } ?>
                        </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
              </tbody>

            </table>

            </div>
            <!-- /.box -->

        <!--</div>-->
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
  $(function () {

    $('#tblRosterVariation').DataTable( {
        "scrollX": true
    } );

    $('#full_date').datepicker({
        autoclose: true,
        minViewMode: 1,
        format: 'yyyy-mm'
    });

  })
</script>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=> 'Roster Variation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\spicknspan\resources\views/backend/pages/roster_variation.blade.php */ ?>