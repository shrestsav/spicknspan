<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-6">
      <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      <?php endif; ?>
      <?php if(\Session::has('message')): ?>
        <div class="alert alert-success custom_success_msg">
            <?php echo e(\Session::get('message')); ?>

        </div>
      <?php endif; ?>
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Add Building</h3>
        </div>
        <form role="form" action="<?php echo e(route('site.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="box-body pad">
            <div class="form-group">
              <label for="b_name">Name</label>
              <input type="text" name="name" class="form-control" id="b_name" placeholder="Enter Name">
            </div>
            <div class="form-group">
              <label for="building_no">Building No</label>
              <input type="text" name="building_no" class="form-control" id="building_no" placeholder="Enter Building Number" required>
            </div>
            <div class="form-group">
              <label for="b_address">Address</label>
              <input type="text" name="address" class="form-control" id="b_address" placeholder="Enter Address" required>
            </div>
            <div class="form-group">
              <label for="b_description">Description</label>
              <textarea name="description" class="form-control" id="b_description" placeholder="Enter Additional Information" required></textarea>
            </div>
            <div class="form-group">
              <label for="b_image">Image</label>
              <input type="file" name="image" class="form-control" id="b_image">
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-6">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Buildings</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="building_list_table" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Name</th>
              <th>Building No</th>
              <th>Address</th>
              <th>Description</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($building->name); ?></td>
                <td><?php echo e($building->building_no); ?></td>
                <td><?php echo e($building->address); ?></td>
                <td><?php echo e($building->description); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Create Division/Area</h3>
        </div>
        <form role="form" action="<?php echo e(route('room.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <div class="box-body pad">
            <div class="form-group">
              <select class="select2" name="building_id">
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($building->id); ?>"><?php echo e($building->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="r_name">Name</label>
              <input type="text" name="name" class="form-control" id="r_name" placeholder="Enter Name">
            </div>

            <div class="form-group">
              <label for="room_no">Room No</label>
              <input type="text" name="room_no" class="form-control" id="room_no" placeholder="Enter Room Number" required>
            </div>
            <div class="form-group">
              <label for="r_description">Description</label>
              <textarea name="description" class="form-control" id="r_description" placeholder="Enter Additional Information" required></textarea>
            </div>
            <div class="form-group">
              <label for="r_image">Image</label>
              <input type="file" name="image" class="form-control" id="r_image">
            </div>
            <div class="form-group">
              <label for="r_image">Select Questionare</label><br>
              <select class="select2" name="question_id">
                <?php $__currentLoopData = $questionTemplate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($qT->id); ?>"><?php echo e($qT->template_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-6">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Rooms</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="room_list_table" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>S.No</th>
              <th>Name</th>
              <th>Room No</th>
              <th>Building No</th>
              <th>Question Template</th>
              <th>QR</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody>
              <?php $count=1; ?>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($count); ?></td>
                <td><?php echo e($room->name); ?></td>
                <td><?php echo e($room->room_no); ?></td>
                <td><?php echo e($room->building_no); ?></td>
                <?php $__currentLoopData = $questionTemplate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($qT->id == $room->question_id){ ?>
                <td><?php echo e($qT->template_title); ?></td>
                <?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><a href="<?php echo e(route('generate.qr',$room->id)); ?>" target="_blank">Show QR</a></td>
                <form action="<?php echo e(url('/site/delete_room/').'/'.$room->id); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="_method" value="POST">
                  <td><button>Delete</button></td>
                </form>
              </tr>
              <?php $count++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $('#building_list_table').DataTable({
      "pageLength": 8,
      "scrollX": true
    });
    $('#room_list_table').DataTable({
      "pageLength": 8,
      "scrollX": true
    });
  })
</script>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=> 'Sites'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>