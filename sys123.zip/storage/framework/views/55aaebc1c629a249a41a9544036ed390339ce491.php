<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-6">
      <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      <?php endif; ?>
      <?php if(\Session::has('message')): ?>
        <div class="alert alert-success custom_success_msg">
            <?php echo e(\Session::get('message')); ?>

        </div>
      <?php endif; ?>
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Employee Information</h3>
        </div>
        <form role="form" action="<?php echo e(route('wages.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="box-body pad">
            <div class="form-group">
              <label for="employee_id">Employee Name</label>
              <select class="form-control" name="employee_id">

                  <?php if($employee->count()): ?>
                          <option selected disabled>Select Employee</option>
                      <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

              </select>
            </div>
            <div class="form-group">
              <label for="client_id">Client Name</label>
              <select class="form-control" name="client_id">

                  <?php if($client->count()): ?>
                          <option selected disabled>Select Client</option>
                      <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

              </select>
            </div>
            <div class="form-group">
              <label for="hourly_rate">Base Hourly Rate ($)</label>
              <input type="number" name="hourly_rate" class="form-control" id="hourly_rate" placeholder="Select Hourly Rate">
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-6">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Employee Wages List</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="employee_wages_table" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Employee</th>
              <th>Client</th>
              <th>Hourly Rate ($)</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $wages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($wage->employee_id == $user1->id): ?>
                              <td><?php echo e($user1->name); ?></td>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($wage->client_id == $user2->id): ?>
                              <td><?php echo e($user2->name); ?></td>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <td><?php echo e($wage->hourly_rate); ?></td>
                      <form action="<?php echo e(url('/wages/').'/'.$wage->id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="POST">
                        <td><button>Delete</button></td>
                      </form>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $('#employee_wages_table').DataTable()
  })
</script>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=> 'Wages'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>