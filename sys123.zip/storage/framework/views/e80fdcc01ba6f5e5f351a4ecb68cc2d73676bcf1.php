<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content attendance_history" style="padding-top: 50px;">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

            <!-- attendance filter part -->
            <div class="box-header">
              <h4 class="box-title">Filter : </h4>
              <form role="form" action="<?php echo e(route('attendance.list')); ?>" method="GET" data-toggle="validator" enctype="multipart/form-data">
                <?php
                    if(isset($_GET['employee_id'])){
                        $filtEmpId = $_GET['employee_id'];
                    } else {
                        $filtEmpId = '';
                    }

                    if(isset($_GET['client_id'])){
                        $filtCliId = $_GET['client_id'];
                    } else {
                        $filtCliId = '';
                    }

                    if(isset($_GET['filt_date'])){
                        $filtDate = $_GET['filt_date'];
                    } else {
                        $filtDate = '';
                    }
                ?>
                  <div class="form-group">
                    <label for="emp_name">Employee Name</label>
                    <select class="select2" name="employee_id">
                        <option value="">--</option>
                      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="client_name">Client Name</label>
                    <select class="select2" name="client_id">
                        <option value="">--</option>
                      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="filt_date">Date</label>
                    <input type="date" name="filt_date" class="form-control" id="filt_date" placeholder="Select Date" <?php echo "value=".$filtDate;?>>
                  </div>
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Search</button>
                  </div>
              </form>
            </div>
            <!-- attendance filter part -->

            <div class="box-header">
              <h3 class="box-title">Attendance</h3>
               <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default" onclick="exportTableToExcel('employee_attendance', 'members-data')"><i class="fa fa-file-excel-o"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover" id="employee_attendance">
                <tr>
                  <th>Date</th>
                  <th>Employee Name</th>
                  <th>Client Name</th>
                  <th>Total Time</th>
                  <th>Timing</th>
                  <th>View Details</th>
                </tr>
                <?php $dataArr = []; ?>
                <?php $__currentLoopData = $attendance_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php  
                      $check_in = \Carbon\Carbon::parse($attendance_list->check_in)->timezone(Session::get('timezone')); 
                      $check_out = \Carbon\Carbon::parse($attendance_list->check_out)->timezone(Session::get('timezone')); 
                      // $hours = $check_out->diffInHours($check_in);
                  ?>
                  <tr>
                    <td><?php echo e($attendance_list->date); ?></td>                   
                    <td><?php echo e($attendance_list->employee_name); ?></td>
                    <td><?php echo e($attendance_list->client_name); ?></td>
                    <td><?php echo e($attendance_list->total_time); ?></td>
                    <td><?php echo e($check_in->format('g:i A')); ?> - 
                        <?php if($attendance_list->check_out!=null || $attendance_list->check_out!=''): ?>
                          <?php echo e($check_out->format('g:i A')); ?><?php else: ?> NOT LOGGED OUT <?php endif; ?></td>
                    <td>
                      <a class="view_att_details btn btn-success" href="<?php echo e(url('attendance/details').'/'.$attendance_list->client_id.'/'.$attendance_list->employee_id.'/'.$attendance_list->date); ?>">Details
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('backend/js/export-table-excel.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=>'Attendance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>