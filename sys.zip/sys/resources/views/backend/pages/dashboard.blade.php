@extends('backend.layouts.app',['title'=>'Dashboard'])

@section('content')

    <!-- Main content -->
    <section class="content" style="padding-top: 50px;">
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header" style="text-align: center;">
              <h3 class="box-title" >Welcome You are Logged In</h3>
            </div>
            <div class="box-body  no-padding">
            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->

@endsection

