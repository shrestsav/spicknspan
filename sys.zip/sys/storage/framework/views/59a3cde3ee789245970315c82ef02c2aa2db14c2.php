
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <?php if(file_exists(public_path('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png'))): ?>
            <img src="<?php echo e(asset('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png')); ?>" class="img-circle" alt="User Image">
          <?php else: ?>
            <img src="<?php echo e(asset('backend/img/user_default.png')); ?>" class="img-circle" alt="User Image">
          <?php endif; ?>
        </div>
        <div class="pull-left info">
          <p><?php echo e(ucfirst(Auth::user()->name)); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">OPERATIONS</li>
        <li class="<?php if($title === 'Check In / Out'): ?> active <?php endif; ?>"><a href="<?php echo e(route('attendance.index')); ?>"><i class="fa fa-sign-in"></i> <span>Check IN/OUT</span></a>
        </li> 
        <li class="<?php if($title === 'Attendance'): ?> active <?php endif; ?>"><a href="<?php echo e(route('attendance.list')); ?>"><i class="fa fa-book"></i> <span>View Attendance</span></a>
        </li>
        <li class="<?php if($title === 'QR Scanner'): ?> active <?php endif; ?>"><a href="<?php echo e(route('scanner')); ?>"><i class="fa fa-search-plus"></i> <span>QR Login</span></a>
        </li>
        <li class="<?php if($title === 'Site Attendance'): ?> active <?php endif; ?>"><a href="<?php echo e(route('site.attendance')); ?>"><i class="fa fa-dashboard"></i> <span>Site Attendance</span></a>
        </li>

      
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <li class="header">SETTINGS</li>
        <li class="treeview <?php if($title === 'Employees' || $title === 'Contractors' || $title === 'Clients'): ?> active <?php endif; ?>">
          <a href="#">
            <i class="fa fa-user-plus"></i> <span>Create</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if($title === 'Employees'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_employee.index')); ?>"><i class="fa fa-users"></i> <span>Employees</span></a>
            </li>
            <li class="<?php if($title === 'Contractors'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_contractor.index')); ?>"><i class="fa fa-pencil-square-o"></i> <span>Contractors</span></a>
            </li>
            <li class="<?php if($title === 'Clients'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_client.index')); ?>"><i class="fa fa-user"></i> <span>Clients</span></a>
            </li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-folder"></i> <span>Operations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if($title === 'Wages'): ?> active <?php endif; ?>"><a href="<?php echo e(route('wages.index')); ?>"><i class="fa fa-circle-o"></i> <span>Wages</span></a>
            </li>
            <li class="<?php if($title === 'Roster'): ?> active <?php endif; ?>"><a href="<?php echo e(route('roster.index')); ?>"><i class="fa fa-circle-o"></i> <span>Roster</span></a>
            </li>
            <li class="<?php if($title === 'Roster Variation'): ?> active <?php endif; ?>"><a href="<?php echo e(route('roster_variation.index')); ?>"><i class="fa fa-circle-o"></i> <span>Roster Variation</span></a>
            </li>
            <li class="<?php if($title === 'Question Template'): ?> active <?php endif; ?>"><a href="<?php echo e(route('question.index')); ?>"><i class="fa fa-circle-o"></i> <span>Question Template</span></a>
            </li>
          </ul>
        </li>
        
        
        <li class="<?php if($title === 'Sites'): ?> active <?php endif; ?>"><a href="<?php echo e(route('site.index')); ?>"><i class="fa fa-dashboard"></i> <span>Sites</span></a>
        </li>

      <?php endif; ?>

       

      </ul>
    </section>
    <!-- /.sidebar -->
