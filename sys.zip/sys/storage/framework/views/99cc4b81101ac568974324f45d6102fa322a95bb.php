    <!-- Logo -->
    <a href="<?php echo e(url('/')); ?>" class="logo">
      <div class="logo-lg">
        <img src="<?php echo e(asset('backend/img/trackncheck.png')); ?>" width="200px;">
      </div>
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><span class="logo-mini_green">T</span><b>&</b><span class="logo-mini_blue">C</span></span>
      <!-- logo for regular state and mobile devices -->
      
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

         

          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <?php if(file_exists(public_path('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png'))): ?>
                <img src="<?php echo e(asset('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png')); ?>" class="user-image" alt="User Image">
              <?php else: ?>
                <img src="<?php echo e(asset('backend/img/user_default.png')); ?>" class="user-image" alt="User Image">
              <?php endif; ?>

              
              <span class="hidden-xs"><?php echo e(ucfirst(Auth::user()->name)); ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <?php if(file_exists(public_path('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png'))): ?>
                  <img src="<?php echo e(asset('files/users/'.Auth::user()->id.'/dp_user_'.Auth::user()->id.'.png')); ?>" class="img-circle" alt="User Image">
                <?php else: ?>
                  <img src="<?php echo e(asset('backend/img/user_default.png')); ?>" class="img-circle" alt="User Image">
                <?php endif; ?>
                <p>
                  <?php echo e(ucfirst(Auth::user()->user_type)); ?>

                  <small></small>
                </p>
              </li>
              <!-- Menu Body -->
              
              <!-- Menu Footer-->
              <li class="user-footer" style="text-align: center;">
                
                <div class="">
                  <a class="btn btn-default btn-flat" href="<?php echo e(route('logout')); ?>"
                     onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                      <?php echo e(__('Sign Out')); ?>

                  </a>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form>
                  
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!-- <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li> -->
        </ul>
      </div>
    </nav>