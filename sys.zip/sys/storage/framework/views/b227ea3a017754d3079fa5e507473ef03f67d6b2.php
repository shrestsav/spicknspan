  

  <?php $__env->startSection('content'); ?>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(\Session::has('message')): ?>
          <div class="alert alert-success custom_success_msg">
              <?php echo e(\Session::get('message')); ?>

          </div>
        <?php endif; ?>
        <div class="container col-sm-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <div class="add-btn">
                <a class="btn btn-primary" href="<?php echo e(route('question.add')); ?>">ADD TEMPLATE</a>
              </div>
              <br>
              <table class="table table-hover">
                <tr>
                  <th>S.N.</th>
                  <!-- <th>Category</th> -->
                  <th>Title</th>
                  <th>Action</th>
                </tr>
                <?php $i = 1;?>
                <?php $__currentLoopData = $qTemplate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo $i;?></td>
                    <!-- <td></td> -->
                    <td><?php echo e($qT->template_title); ?></td>
                    <td>
                      <a href="<?php echo e(url('/questionTemplate',$qT->id)); ?>">
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                      </a>
                      <a href="javascript:;" id="delete_qT" data-user_id = '<?php echo e($qT->id); ?>'><i class="fa fa-trash" aria-hidden="true"></i>
                      </a>
                    </td>
                    <!-- <form action="<?php echo e(url('/questionTemplate/').'/'.$qT->id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="POST">
                        <td><button>Delete</button></td>
                      </form> -->
                  </tr>
                  <?php $i++;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php $__env->stopSection(); ?>

  <?php $__env->startPush('scripts'); ?>
  <script type="text/javascript">
    $(function () {
        $('#delete_qT').on('click',function(){
          swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
          .then((willDelete) => {
            if (willDelete) {
              var user_id = $(this).data('user_id');
              alert(user_id);
              window.location.href = "<?php echo e(url('questionTemplate/')); ?>/"+user_id;
            } 
          });
        });
    });
  </script>    
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=> 'Question Template'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>