<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Logged in Users</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="site_attendance_table" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Name</th>
              <th>Room No</th>
              <th>Building No</th>
              <th>Address</th>
              <th>Login Time</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $site_attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site_attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($site_attendance->name); ?></td>
                <td><?php echo e($site_attendance->room_no); ?></td>
                <td><?php echo e($site_attendance->building_no); ?></td>
                <td><?php echo e($site_attendance->address); ?></td>
                <td><?php echo e($site_attendance->login); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $('#site_attendance_table').DataTable({
      "pageLength": 8
    });
  })
</script>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=> 'Site Attendance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>